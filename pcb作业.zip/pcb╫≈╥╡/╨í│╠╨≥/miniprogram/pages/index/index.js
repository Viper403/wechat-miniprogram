//index.js
const app = getApp()
var wxCharts = require("../../utils/wxcharts-min.js");
var windowW = 0;
//获取数据库引用
const db = wx.cloud.database({ env: 'bluetoothtest-yrn06'});
const bleDB = db.collection('ble');
var list = [];
function strToHexCharCode(str) {
  　　if (str === "")
    　　　　return "";
  　　var hexCharCode = [];
  　　hexCharCode.push("0x");
  　　for (var i = 0; i < str.length; i++) {
    　　　　hexCharCode.push((str.charCodeAt(i)).toString(16));
  　　}
  　　return hexCharCode.join("");
}
function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i;
    }
  }
  return -1;
}

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      // console.log("bit: ", bit, bit.toString(16))
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',');
}

// 16 
function hex2str(str) {
  let val = ''
  var arr = str.split(",");
  for (let i = 0; i < arr.length; i++) {
    val += String.fromCharCode(parseInt(arr[i], 16));
  }
  return val
}

Page({
  data: {
    receiveData: null,
    sendData: null,
    capsuleInfo: app.globalData.capsuleInfo,
    title: ''
  },

  inputSend: function(e) {
    console.log(e.detail.value);
    this.setData({ sendData: e.detail.value})
  },

  onLoad: function (options) {
    this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth,
      title: options.deviceName,
      deviceId: app.globalData.deviceId,
      readServiceUUID: app.globalData.readServiceUUID,
      readCharacteristicUUID : app.globalData.readCharacteristicUUID,
      writeServiceUUID: app.globalData.writeServiceUUID,
      writeCharacteristicUUID: app.globalData.writeCharacteristicUUID,
      notifyServiceUUID: app.globalData.notifyServiceUUID,
      notifyCharacteristicUUID: app.globalData.notifyCharacteristicUUID 
    });
    console.log(this.data.imageWidth);

    //计算屏幕宽度比列
    windowW = this.data.imageWidth / 375;
    console.log(windowW);

    console.log(options)
    if (options.notify == '0') {
      this.setData({notify: true})
    } else {
      this.setData({ notify: false })
    }
  },
  onShow: function () {
    // columnCanvas
    new wxCharts({
      canvasId: 'columnCanvas',
      type: 'column',
      animation: true,
      categories: [2001, 2002, 2003, 2004, 2005],
      series: [{
        name: '成交量',
        data: [15.00, 20.00, 45.00, 37.00],
        format: function (val, name) {
          return val.toFixed(2) + '万';
        }
      }, {
        name: '成交量',
        data: list,
        format: function (val, name) {
          return val.toFixed(2) + '米';
        },

      }],
      yAxis: {
        format: function (val) {
          return val + '万';
        },
        title: 'hello',
        min: 0
      },
      xAxis: {
        disableGrid: false,
        type: 'calibration'
      },
      extra: {
        column: {
          width: 15
        }
      },
      width: (375 * windowW),
      height: (200 * windowW),
    });


  },

  writeBLECharacteristicValue() {
    let _this = this
    let value = this.data.sendData
    if (!value || value.length == 0) {
      wx.showToast({
        title: '内容为空！',
        icon: 'none'
      })
      return;
    }
    let hex = strToHexCharCode(value);
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    let buffer = typedArray.buffer
    wx.writeBLECharacteristicValue({
      deviceId: _this.data.deviceId,
      serviceId: _this.data.writeServiceUUID[0],
      characteristicId: _this.data.writeCharacteristicUUID[0],
      value: buffer,
      success: res => { 
        console.log("写入成功");
        wx.showToast({
          title: "写入成功",
        })
      },
      fail: res => { console.log("fail", res) }
    })
  },

  receiveBLE() {
    var that = this;
    if (!this.data.notify) {
      wx.showModal({
        title: '提示',
        content: '请开启蓝牙监听',
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
            that.readBLECharacteristicValue();
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
    console.log("开始接收数据");
    this.setData({read: true})
    wx.onBLECharacteristicValueChange(function (res) {
      console.log("value: ", res.value)
      console.log("characteristicId：" + res.characteristicId)
      console.log("serviceId:" + res.serviceId)
      console.log("deviceId" + res.deviceId)
      console.log("Length:" + res.value.byteLength)
      console.log("hexvalue:" + ab2hex(res.value))
      console.log("strvalue: " + hex2str(ab2hex(res.value)))
      list.push(parseInt(ab2hex(res.value), 16))
      console.log(list)
      that.setData({
        receiveData: parseInt(ab2hex(res.value),16)
      })
    })
  },
  saveToDB: function() {
    let content = this.data.receiveData;
    let timeStamp = Date.now()
    let _this = this;
    console.log("save to DB");
    bleDB.add({
      data: { content: content, timeStamp: timeStamp}
    })
      .then(res => { 
        console.log("保存成功"); 
        wx.showToast({
          title: "保存成功"
        })
        _this.setData({receiveData: ''}) })
      .catch(res => { console.log("保存失败") })
  },
  onUnload: function () {
    console.log('//如果页面被卸载时被执行');
    // this.gotoHomePage();
    wx.closeBLEConnection({
      deviceId: app.globalData.deviceId,
      success(res) {
        console.log(res);
        wx.showToast({
          title: '已断开蓝牙连接',
        })
      }
    })
  },

  readBLECharacteristicValue() {
    let _this = this
    var notifyServicweId = _this.data.notifyServiceUUID[0];  //具有写、通知属性的服务uuid
    var notifyCharacteristicsId = _this.data.notifyCharacteristicUUID[0];
    console.log("启用notify的serviceId", notifyServicweId);
    console.log("启用notify的notifyCharacteristicsId", notifyCharacteristicsId);
    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      deviceId: _this.data.deviceId,
      // 这里的 serviceId 就是_this.data.servicesUUID
      serviceId: notifyServicweId,
      characteristicId: notifyCharacteristicsId,
      success: function (res) {
        console.log('notifyBLECharacteristicValueChange success', res.errMsg)
        wx.showToast({
          title: '开启成功',
        })
      },
      fail: function (res) {
        console.log('启动notify:' + res.errMsg);
        wx.showToast({
          title: '开启失败',
          icon: 'none'
        })
      },
    })
  },

  onGetOpenid: function() {
    // 调用云函数
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        app.globalData.openid = res.result.openid
        wx.navigateTo({
          url: '../userConsole/userConsole',
        })
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        wx.navigateTo({
          url: '../deployFunctions/deployFunctions',
        })
      }
    })
  },

  // 上传图片
  doUpload: function () {
    // 选择图片
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {

        wx.showLoading({
          title: '上传中',
        })

        const filePath = res.tempFilePaths[0]
        
        // 上传图片
        const cloudPath = 'my-image' + filePath.match(/\.[^.]+?$/)[0]
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)

            app.globalData.fileID = res.fileID
            app.globalData.cloudPath = cloudPath
            app.globalData.imagePath = filePath
            
            wx.navigateTo({
              url: '../storageConsole/storageConsole'
            })
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading()
          }
        })

      },
      fail: e => {
        console.error(e)
      }
    })
  },

})
