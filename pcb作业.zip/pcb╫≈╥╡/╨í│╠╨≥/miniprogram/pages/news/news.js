// pages/news/news.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemsData: [
      {
        "slogan": "斯坦福高效睡眠法",
        "image": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1584358816470&di=eb8b25640a129bb6bf020ca63531d9a6&imgtype=0&src=http%3A%2F%2Fimg1.gtimg.com%2Fcq%2Fpics%2Fhv1%2F227%2F52%2F2261%2F147035012.jpg",
        "icon": "http://img.kaiyanapp.com/fa20228bc5b921e837156923a58713f6.png",
        "url": "https://book.douban.com/subject/30351542",
        "page":"../web1/web1"
      },
      {
        "slogan": "如何进入深度睡眠",
        "image": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1584358628513&di=2630e61d1090f6952cc029c6eaad330e&imgtype=0&src=http%3A%2F%2Fimg1.gtimg.com%2Fjiangsu%2Fpics%2Fhv1%2F201%2F46%2F2300%2F149569431.jpg",
        "icon": "http://img.kaiyanapp.com/fa20228bc5b921e837156923a58713f6.png",
        "url": "https://book.douban.com/subject/30528347",
        "page": "../web2/web2"
        
      },
      {
        "slogan": "找回婴儿般的好睡眠",
        "image": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1584358628514&di=681132c37f6a0aafdae4409d7cdd780c&imgtype=0&src=http%3A%2F%2Fn.sinaimg.cn%2Fsina_vr%2Fcrawl%2F119%2Fw550h369%2F20200227%2F4b59-ipzreiw7858378.jpg",
        "icon": "http://img.kaiyanapp.com/fa20228bc5b921e837156923a58713f6.png",
        "url": "https://book.douban.com/subject/27092880",
        "page": "../web3/web3"
      },
      {
        "slogan": "嵌入式设备改善生活",
        "image": "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1117703812,3294135042&fm=26&gp=0.jpg",
        "icon": "http://img.kaiyanapp.com/fa20228bc5b921e837156923a58713f6.png",
        "url": "https://m.cnmo.com/tags/096tfn",
        "page": "../web4/web4"
      },
      {
        "slogan": "人工智能新时代",
        "image": "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1584358758056&di=5a1687aa562f256d96830281dfe0b6af&imgtype=0&src=http%3A%2F%2Fwww.lovehhy.net%2Flib%2Fimg%2F2140390%2F623163_0051402220.jpg",
        "icon": "http://img.kaiyanapp.com/fa20228bc5b921e837156923a58713f6.png",
        "url": "https://ai.baidu.com",
        "page": "../web5/web5"
      }

    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})