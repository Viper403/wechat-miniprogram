//云数据库初始化
const db = wx.cloud.database({ env: 'bluetoothtest-yrn06' });
const cont = db.collection('ble');
const MAX_LIMIT = 100;

Page({
  data: {
    ne: [],  //这是一个空的数组，等下获取到云数据库的数据将存放在其中
    condition: 10,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this;
    //1、引用数据库   
    const db = wx.cloud.database({
      //这个是环境ID不是环境名称     
      env: 'bluetoothtest-yrn06'
    })
    //2、开始查询数据了  news对应的是集合的名称   
    db.collection('ble').get({
      //如果查询成功的话    
      success: res => {
        //console.log(res.data)
        //这一步很重要，给ne赋值，没有这一步的话，前台就不会显示值      
        this.setData({
          ne: res.data
        })
      }
    })
  },
  getdata: function (event) {
    db.collection('ble').where({
      _openid: "op4c_5dNv1pH0hYTQoqhMTOCd-QE"
    }).get().then(res => {
      var datalist = []
      var datelen = res.data.length;
      for (let i = 0; i < res.data.length; i++) {
        //console.log(res.data[0])
        datalist.push(res.data[i].content)
      }

      console.log(datalist)
      this.getdeviation(datalist)
    })

  },
  getdeviation: function (list) {
    var covlist = []
    var total = 0
    var len = list.length
    var flag = 0;
    for (let i = 0; i < len; i++) {
      total += list[i]
    }
    var average = total / len;
    var std = 0;
    for (let i = 0; i < len; i++) {
      std += ((list[i] - average) * (list[i] - average)) / (len - 1)
    }
    console.log(average)
    console.log(Math.sqrt(std))
    var j = 0;
    for (let i = 0; i < len; i++) {
      if (list[i] < average - Math.sqrt(std) || list[i] > average + Math.sqrt(std)) {
        j += 1
      }
    }
    console.log(j)
    //console.log(total)
    var cov = 0;
    var ru = 0;
    for (let k = 1; k < 7; k++) {
      for (let i = 0; i < len - k; i++) {
        cov += (list[i] - average) * (list[i + k] - average)
      }
      ru = (cov / (len - k)) / std
      console.log(ru)
      covlist.push(ru)
    }
    console.log(covlist)
    if (j <= 3 && covlist[covlist.length - 1] < 0.5)
      flag = 1
    else if (j <= 3 && covlist[covlist.length - 1] >= 0.5)
      flag = 2
    else if (j > 3 && covlist[covlist.length - 1] <= 0.5)
      flag = 3
    else
      flag = 4
    this.setData({
      condition: flag
    })

  },

})