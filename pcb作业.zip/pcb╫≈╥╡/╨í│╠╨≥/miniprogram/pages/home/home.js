// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  
  _BLE: function() {
    wx.navigateTo({
      url: '../conn/conn',
    })
  },
  _ACC: function() {
    wx.navigateTo({
      url: '../acc/acc',
    })
  }
})