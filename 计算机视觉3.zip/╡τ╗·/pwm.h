#ifndef __PWM_H_
#define __PWM_H_

#include "delay.h"

extern void PWM6_Configuration(void);

#endif
