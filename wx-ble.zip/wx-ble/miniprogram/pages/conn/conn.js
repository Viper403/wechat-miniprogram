const app = getApp()

function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i;
    }
  }
  return -1;
}
// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      // console.log("bit: ", bit, bit.toString(16))
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',');
}

// 16 
function hex2str(str) {
  let val = ''
  var arr = str.split(",");
  for (let i = 0; i < arr.length; i++) {
    val += String.fromCharCode(parseInt(arr[i], 16));
  }
  return val
}

Page({
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    devices: [],
    connected: false,
    chs: [],
    readServiceUUID: [],
    readCharacteristicUUID: [],
    writeServiceUUID: [],
    writeCharacteristicUUID: [],
    notifyServiceUUID: [],
    notifyCharacteristicUUID: []
  },
  openBluetoothAdapter() {
    console.log("openBluetoothAdapter")
    wx.openBluetoothAdapter({
      success: (res) => {
        console.log('openBluetoothAdapter success', res)
        this.startBluetoothDevicesDiscovery()
      },
      fail: (res) => {
        console.log(res)
        if (res.errCode === 10001) {
          console.log("onBluetoothAdapterStateChange")
          wx.showToast({ title: '请打开手机蓝牙！', icon: 'none' })
        }
      }
    })
  },
  getBluetoothAdapterState() {
    wx.getBluetoothAdapterState({
      success: (res) => {
        console.log('getBluetoothAdapterState', res)
        if (res.discovering) {
          this.onBluetoothDeviceFound()
        } else if (res.available) {
          this.startBluetoothDevicesDiscovery()
        }
      }
    })
  },
  startBluetoothDevicesDiscovery() {
    if (this._discoveryStarted) {
      return
    }
    this._discoveryStarted = true
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: (res) => {
        console.log('startBluetoothDevicesDiscovery success', res)
        this.onBluetoothDeviceFound()
      },
    })
  },
  stopBluetoothDevicesDiscovery() {
    wx.stopBluetoothDevicesDiscovery()
  },
  onBluetoothDeviceFound() {
    wx.onBluetoothDeviceFound((res) => {
      res.devices.forEach(device => {
        /*if (!device.name && !device.localName) {
          return
        }*/
        const foundDevices = this.data.devices
        const idx = inArray(foundDevices, 'deviceId', device.deviceId)
        const data = {}
        if (idx === -1) {
          data[`devices[${foundDevices.length}]`] = device
        } else {
          data[`devices[${idx}]`] = device
        }
        this.setData(data)
      })
    })
  },
  createBLEConnection(e) {
    console.log("连接蓝牙。。。")
    wx.showLoading({
      title: '连接中...',
    })
    let _this = this
    const ds = e.currentTarget.dataset
    const deviceId = ds.deviceId
    const name = ds.name
    wx.createBLEConnection({
      deviceId,
      success: (res) => {
        wx.hideLoading()
        this.setData({
          connected: true,
          name,
          deviceId,
          canWrite: true
        })
        this.getBLEDeviceServices(deviceId)
        wx.showModal({
          title: '提示',
          content: '已连接到' + _this.data.name + '，是否开启蓝牙监听',
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
              _this.readBLECharacteristicValue();
              // _this.receiveBLE();
              wx.navigateTo({
                url: `../index/index?deviceName=${_this.data.name}&notify=0`,
              })
            } else if (res.cancel) {
              console.log('用户点击取消')
              wx.navigateTo({
                url: `../index/index?deviceName=${_this.data.name}&notify=1`,
              })
            }
          }
        })
      }
    })
    this.stopBluetoothDevicesDiscovery()
  },
  closeBLEConnection() {
    wx.closeBLEConnection({
      deviceId: this.data.deviceId
    })
    this.setData({
      connected: false,
      chs: [],
      canWrite: false,
    })

  },
  getBLEDeviceServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId,
      success: (res) => {
        for (let i = 0; i < res.services.length; i++) {
          console.log("service: ", res.services)
          // if (res.services[i].isPrimary) {
          console.log("res.services[i].uuid: ", res.services[i].uuid)
          this.getBLEDeviceCharacteristics(deviceId, res.services[i].uuid)
          // return
          // }
        }
      }
    })
  },
  getBLEDeviceCharacteristics(deviceId, serviceId) {
    console.log("deviceId: ", deviceId)
    console.log("serviceId: ", serviceId)
    let _this = this
    wx.getBLEDeviceCharacteristics({
      deviceId,
      serviceId,
      success: (res) => {
        console.log('getBLEDeviceCharacteristics success', res.characteristics)
        for (let i = 0; i < res.characteristics.length; i++) {
          let item = res.characteristics[i]
          if (item.properties.read) {
            let readServiceUUID = _this.data.readServiceUUID.concat(serviceId);
            let readCharacteristicUUID = _this.data.readCharacteristicUUID.concat(item.uuid);
            _this.setData({
              readServiceUUID: readServiceUUID,
              readCharacteristicUUID: readCharacteristicUUID
            })
            wx.readBLECharacteristicValue({
              deviceId,
              serviceId,
              characteristicId: item.uuid,
            })
          }
          if (item.properties.write) {
            let writeServiceUUID = _this.data.writeServiceUUID.concat(serviceId);
            let writeCharacteristicUUID = _this.data.writeCharacteristicUUID.concat(item.uuid);
            _this.setData({
              canWrite: true,
              writeServiceUUID: writeServiceUUID,
              writeCharacteristicUUID: writeCharacteristicUUID
            })
            _this._deviceId = deviceId
            _this._serviceId = serviceId
            _this._characteristicId = item.uuid
            // _this.writeBLECharacteristicValue()
          }
          if (item.properties.notify || item.properties.indicate) {
            let notifyServiceUUID = _this.data.notifyServiceUUID.concat(serviceId);
            let notifyCharacteristicUUID = _this.data.notifyCharacteristicUUID.concat(item.uuid);
            _this.setData({
              notifyServiceUUID: notifyServiceUUID,
              notifyCharacteristicUUID: notifyCharacteristicUUID,
            })
            wx.notifyBLECharacteristicValueChange({
              deviceId,
              serviceId,
              characteristicId: item.uuid,
              state: true,
            })
          }
        }
        
        app.globalData.deviceId = deviceId;
        console.log("deviceId: ", deviceId)
        app.globalData.deviceName = _this.data.name;
        console.log("deviceName: ", app.globalData.deviceName)
        app.globalData.readServiceUUID = _this.data.readServiceUUID;
        app.globalData.readCharacteristicUUID = _this.data.readCharacteristicUUID;
        app.globalData.writeServiceUUID = _this.data.writeServiceUUID;
        app.globalData.writeCharacteristicUUID = _this.data.writeCharacteristicUUID;
        app.globalData.notifyServiceUUID = _this.data.notifyServiceUUID;
        app.globalData.notifyCharacteristicUUID = _this.data.notifyCharacteristicUUID;
        console.log("readServiceUUID: ", _this.data.readServiceUUID, app.globalData.readServiceUUID);
        console.log("readCharacteristicUUID: ", _this.data.readCharacteristicUUID);
        console.log("writeServiceUUID: ", _this.data.writeServiceUUID);
        console.log('writeCharacteristicUUID: ', _this.data.writeCharacteristicUUID);
        console.log("notifyServiceUUID: ", _this.data.notifyServiceUUID);
        console.log("notifyCharacteristicUUID: ", _this.data.notifyCharacteristicUUID);

      },
      fail(res) {
        console.error('getBLEDeviceCharacteristics', res)
      }
    })
    // 操作之前先监听，保证第一时间获取数据
    wx.onBLECharacteristicValueChange((characteristic) => {
      const idx = inArray(this.data.chs, 'uuid', characteristic.characteristicId)
      const data = {}
      if (idx === -1) {
        data[`chs[${this.data.chs.length}]`] = {
          uuid: characteristic.characteristicId,
          value: ab2hex(characteristic.value)
        }
      } else {
        data[`chs[${idx}]`] = {
          uuid: characteristic.characteristicId,
          value: ab2hex(characteristic.value)
        }
      }
      _this.setData(data)
    })
  },

  readBLECharacteristicValue() {
    let _this = this
    var notifyServicweId = _this.data.notifyServiceUUID[0];  //具有写、通知属性的服务uuid
    var notifyCharacteristicsId = _this.data.notifyCharacteristicUUID[0];
    console.log("启用notify的serviceId", notifyServicweId);
    console.log("启用notify的notifyCharacteristicsId", notifyCharacteristicsId);
    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      deviceId: _this.data.deviceId,
      // 这里的 serviceId 就是_this.data.servicesUUID
      serviceId: notifyServicweId,
      characteristicId: notifyCharacteristicsId,
      success: function (res) {
        console.log('notifyBLECharacteristicValueChange success', res.errMsg)
        var msg = '启动notify:' + res.errMsg
        _this.setData({
          info: msg
        })
      },
      fail: function (res) {
        console.log('启动notify:' + res.errMsg);

      },
    })
  },

  closeBluetoothAdapter() {
    wx.closeBluetoothAdapter()
    this._discoveryStarted = false
    wx.switchTab({
      url: '../db/db',
    })
  },

})
